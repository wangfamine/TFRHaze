import os
import glob
import re
from PIL import Image

# 输入和输出路径
input_dir = r"D:\TFRHaze\hongwaitu\data"
output_dir = r"D:\TFRHaze\hongwaitu\out"


os.makedirs(output_dir, exist_ok=True)


image_files = glob.glob(os.path.join(input_dir, "*.png"))


def extract_number(filename):
    numbers = re.findall(r'\d+', os.path.basename(filename))
    return int(numbers[0]) if numbers else 0


image_files.sort(key=extract_number)

# 重新命名并保存图片
for idx, image_file in enumerate(image_files, start=1):
    img = Image.open(image_file)
    new_name = f"{idx}_thermal_foggy_1.5.png"
    img.save(os.path.join(output_dir, new_name))

print("Thermal images saved successfully.")