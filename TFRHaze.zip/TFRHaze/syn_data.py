import os, argparse, cv2, random, re
import numpy as np
from skimage import exposure

low_para_list = [
    {'light_max': 4.0, 'light_min': 3.5, "noise_max": 0.05, "noise_min": 0.03},
    {'light_max': 3.0, 'light_min': 2.5, "noise_max": 0.05, "noise_min": 0.03},
    {'light_max': 2.3, 'light_min': 1.8, "noise_max": 0.05, "noise_min": 0.03}
]

haze_para_list = [
    {'beta_max': 2.0, 'beta_min': 1.8, "A_max": 1.0, "A_min": 0.8},
    {'beta_max': 1.7, 'beta_min': 1.4, "A_max": 0.7, "A_min": 0.6},
    {'beta_max': 1.3, 'beta_min': 1.0, "A_max": 0.55, "A_min": 0.45}
]

def select_rain_masks(mask_dir):
    # 定义三个 bin 的范围
    bin_ranges = {
        "bin1": range(1, 41),
        "bin2": range(55, 96),
        "bin3": range(110, 166)
    }

    # 初始化存储三个 bin 的字典
    bins = {"bin1": [], "bin2": [], "bin3": []}

    # 正则表达式用于提取文件名中的 x 值
    pattern = re.compile(r"(\d+)-\d+\.png")

    # 遍历 mask 文件夹中的所有文件
    for filename in os.listdir(mask_dir):
        # 匹配文件名格式并提取 x 值
        match = pattern.match(filename)
        if match:
            x_value = int(match.group(1))
            
            # 根据 x 值分配到对应的 bin
            if x_value in bin_ranges["bin1"]:
                bins["bin1"].append(filename)
            elif x_value in bin_ranges["bin2"]:
                bins["bin2"].append(filename)
            elif x_value in bin_ranges["bin3"]:
                bins["bin3"].append(filename)

    # 从每个 bin 随机选择一张图片
    selected_masks = []
    for bin_name, bin_files in bins.items():
        if bin_files:
            selected_file = random.choice(bin_files)
            selected_masks.append(os.path.join(mask_dir, selected_file))
        else:
            print(f"Warning: {bin_name} 没有可用的文件！")

    return selected_masks

def guideFilter(I, p, winSize, eps):
    mean_I = cv2.blur(I, winSize)
    mean_p = cv2.blur(p, winSize)
    mean_II = cv2.blur(I * I, winSize)
    mean_Ip = cv2.blur(I * p, winSize)
    var_I = mean_II - mean_I * mean_I
    cov_Ip = mean_Ip - mean_I * mean_p
    a = cov_Ip / (var_I + eps)
    b = mean_p - a * mean_I
    mean_a = cv2.blur(a, winSize)
    mean_b = cv2.blur(b, winSize)
    q = mean_a * I + mean_b
    return q

def syn_low(img, light, img_gray, light_max=4.0,
            light_min=3.5, noise_max=0.08, noise_min=0.05):
    light = guideFilter(light, img_gray,(3,3),0.01)[:, :, np.newaxis]
    n = np.random.uniform(noise_min, noise_max)
    R = img / (light + 1e-7)
    L = (light + 1e-7) ** np.random.uniform(light_min, light_max)
    return np.clip(R * L + np.random.normal(0, n, img.shape), 0, 1)

def syn_haze(img, depth, beta_max=2.3, beta_min=1.8, A_max=0.9, A_min=0.6,
                 color_max=0, color_min=0):
    beta = np.random.rand(1) * (beta_max - beta_min) + beta_min
    t = np.exp(-np.minimum(1 - cv2.blur(depth,(22,22)),0.7) * beta)
    A = np.random.rand(1) * (A_max - A_min) + A_min
    A_random = np.random.rand(3) * (color_max - color_min) + color_min
    A = A + A_random
    return np.clip(img * t + A * (1 - t), 0, 1)

def syn_data(hq_file, light_file, depth_file, rain_file, snow_file, out_file, 
             low, haze, rain, snow):
    file_list = os.listdir(hq_file)
    # print(file_list)
    rain_list = os.listdir(rain_file)
    snow_list = os.listdir(snow_file)
    num_rain = random.sample(range(0,len(rain_list)),len(rain_list))
    num_snow = random.sample(range(0,len(snow_list)),len(snow_list))
    for i in range(0, len(file_list)):
        print(file_list[i])
        img = cv2.imread(hq_file+file_list[i])
        w, h, _ = img.shape
        light = cv2.cvtColor(cv2.imread(light_file + file_list[i]), cv2.COLOR_RGB2GRAY) / 255.0
        depth = cv2.imread(depth_file + file_list[i]) / 255.0
        rain_masks = select_rain_masks(rain_file)
        rain_mask_list = []
        snow_mask_list = []
        for rain_mask in rain_masks:
            rain_mask_list.append(cv2.resize(cv2.imread(rain_mask) / 255.0, (h, w)))
        for snow_mask in os.listdir(snow_file):
            snow_mask_list.append(cv2.resize(cv2.imread(os.path.join(snow_file, snow_mask)) / 255.0, (h, w)))
        img_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)/ 255.0
        
        color_dis  = 1

        # haze
        cnt = 0
        for haze_para in haze_para_list:
            lq = img.copy()/255.0
            lq = syn_haze(lq, depth, **haze_para)
            out = lq*255.0
            cv2.imwrite(os.path.join(out_file, 'haze', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
            cnt += 1
        
        # low 
        cnt = 0
        for low_para in low_para_list:
            lq = img.copy()/255.0
            lq = syn_low(lq, light, img_gray, **low_para)
            out = lq*255.0
            cv2.imwrite(os.path.join(out_file, 'low', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
            cnt += 1
            
        # rain
        cnt = 0
        for rain_mask in rain_mask_list:
            lq = img.copy()/255.0
            lq = lq+rain_mask
            out = lq*255.0
            cv2.imwrite(os.path.join(out_file, 'rain', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
            cnt += 1
        
        # snow
        cnt = 0
        for snow_mask in snow_mask_list:
            lq = img.copy()/255.0
            lq = lq*(1-snow_mask)+color_dis*snow_mask
            out = lq*255.0
            cv2.imwrite(os.path.join(out_file, 'snow', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
            cnt += 1
        
        # low_haze
        cnt = 0
        for low_para in low_para_list:
            lq = img.copy()/255.0
            lq = syn_low(lq, light, img_gray, **low_para)
            for haze_para in haze_para_list:
                lq_ = lq.copy()
                lq_ = syn_haze(lq_, depth, **haze_para)
                out = lq_*255.0
                cv2.imwrite(os.path.join(out_file, 'low_haze', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
                cnt += 1
                
        # low_haze_rain
        cnt = 0
        for low_para in low_para_list:
            lq = img.copy()/255.0
            lq = syn_low(lq, light, img_gray, **low_para)
            for rain_mask in rain_mask_list:
                lq_ = lq.copy()
                lq_ = lq_+rain_mask
                for haze_para in haze_para_list:
                    lq__ = lq_.copy()
                    lq__ = syn_haze(lq__, depth, **haze_para)
                    out = lq__*255.0
                    cv2.imwrite(os.path.join(out_file, 'low_haze_rain', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
                    cnt += 1
                    
        # low_haze_rain
        cnt = 0
        for low_para in low_para_list:
            lq = img.copy()/255.0
            lq = syn_low(lq, light, img_gray, **low_para)
            for snow_mask in snow_mask_list:
                lq_ = lq.copy()
                lq_ = lq_*(1-snow_mask)+color_dis*snow_mask
                for haze_para in haze_para_list:
                    lq__ = lq_.copy()
                    lq__ = syn_haze(lq__, depth, **haze_para)
                    out = lq__*255.0
                    cv2.imwrite(os.path.join(out_file, 'low_haze_snow', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
                    cnt += 1
        
        # haze_rain
        cnt = 0
        for rain_mask in rain_mask_list:
            lq = img.copy()/255.0
            lq = lq+rain_mask
            for haze_para in haze_para_list:
                lq_ = lq.copy()
                lq_ = syn_haze(lq_, depth, **haze_para)
                out = lq_*255.0
                cv2.imwrite(os.path.join(out_file, 'haze_rain', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
                cnt += 1
        
        # haze_snow
        cnt = 0
        for snow_mask in snow_mask_list:
            lq = img.copy()/255.0
            lq = lq*(1-snow_mask)+color_dis*snow_mask
            for haze_para in haze_para_list:
                lq_ = lq.copy()
                lq_ = syn_haze(lq_, depth, **haze_para)
                out = lq_*255.0
                cv2.imwrite(os.path.join(out_file, 'haze_snow', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
                cnt += 1
        
        # low_rain
        cnt = 0
        for low_para in low_para_list:
            lq = img.copy()/255.0
            lq = syn_low(lq, light, img_gray, **low_para)
            for rain_mask in rain_mask_list:
                lq_ = lq.copy()
                lq_ = lq_+rain_mask
                out = lq_*255.0
                cv2.imwrite(os.path.join(out_file, 'low_rain', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
                cnt += 1
                
        # low_snow 
        cnt = 0
        for low_para in low_para_list:
            lq = img.copy()/255.0
            lq = syn_low(lq, light, img_gray, **low_para)
            for snow_mask in snow_mask_list:
                lq_ = lq.copy()
                lq_ = lq_*(1-snow_mask)+color_dis*snow_mask
                out = lq_*255.0
                cv2.imwrite(os.path.join(out_file, 'low_snow', file_list[i].split('.')[0] + '_' + str(cnt) + '.png'), out)
                cnt += 1
        
        # if low:
        #     # lq = syn_low(lq, light, img_gray)
        #     lq = syn_low(lq, light, img_gray, **low_para_list[-1])
        # if rain:
        #     lq = lq+rain_mask
        # if snow:
        #     lq = lq*(1-snow_mask)+color_dis*snow_mask
        # if haze:
        #     lq = syn_haze(lq, depth)

        # out = np.concatenate((lq*255.0,img),1)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
     # load model
    parser.add_argument("--hq-file", type=str, default = './data/clear/')
    parser.add_argument("--light-file", type=str, default = './data/light_map/')
    parser.add_argument("--depth-file", type=str, default = './data/depth_map/')
    # parser.add_argument("--rain-file", type=str, default = './data/rain_mask/')

    parser.add_argument("--rain-file", type=str, default = '../../RainStreakGen/data/Streaks_Garg06')
    parser.add_argument("--snow-file", type=str, default = './data/snow_mask/')
    parser.add_argument("--out-file", type=str, default = '../../data/VCD/train/degraded/')
    parser.add_argument("--low", action='store_true')
    parser.add_argument("--haze", action='store_true')
    parser.add_argument("--rain", action='store_true')
    parser.add_argument("--snow", action='store_true')
    
    args = parser.parse_args()

    syn_data(args.hq_file, args.light_file, args.depth_file, args.rain_file, 
             args.snow_file, args.out_file, args.low, args.haze, args.rain, args.snow)