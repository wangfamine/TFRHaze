import torch
import torch.nn as nn
import torch.nn.functional as F
from .basic import Conv, CPAB, Encoder, Decoder, Edge, AdaptiveCrossAttention
from .DSFE import DSFE
from .basic import LightweightTransformer

class tfrhaze(nn.Module):
    def __init__(self, input_nc, output_nc, n_feat=64, kernel_size=3, reduction=4,
                 bias=False):
        super(tfrhaze, self).__init__()

        self.inf_layer1 = nn.Sequential(Conv(input_nc, n_feat, kernel_size, bias=bias),
                                        CPAB(n_feat, kernel_size, bias),
                                        CPAB(n_feat, kernel_size, bias))
        self.rgb_layer1 = nn.Sequential(
            LightweightTransformer(
                in_channels=input_nc,
                embed_dim=n_feat,
                num_heads=4
            ),
            Conv(n_feat, n_feat, 3)  # 保持通道对齐
        )

        # 雾浓度评估模块
        self.fog_estimator = nn.Sequential(
            nn.AdaptiveAvgPool2d(16),  # 降采样到16x16，足够评估大范围雾浓度
            nn.Conv2d(input_nc, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),   # 全局信息聚合
            nn.Conv2d(16, 8, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(8, 1, 1),
            nn.Sigmoid()               # 输出0-1之间的雾浓度估计
        )

        self.inf_encoder = Encoder(n_feat, kernel_size, bias, atten=False)
        self.inf_decoder = Decoder(n_feat, kernel_size, bias, residual=True)

        self.rgb_encoder = Encoder(n_feat, kernel_size, bias, atten=True)
        self.rgb_decoder = Decoder(n_feat, kernel_size, bias, residual=True)

        self.conv = Conv(n_feat, output_nc, kernel_size=1, bias=bias)

        # DSFE Module
        self.inf_structure = DSFE(n_feat, kernel_size, bias)
        self.rgb_structure = DSFE(n_feat, kernel_size, bias)

        #交叉注意力模块
        self.cross_attention = nn.ModuleList([
            AdaptiveCrossAttention(n_feat),
            AdaptiveCrossAttention(n_feat * 2),
            AdaptiveCrossAttention(n_feat * 4)
        ])

    def forward(self, rgb, inf):
        # 评估雾浓度
        fog_level = self.fog_estimator(rgb)
        
        # 红外图像特征提取分支
        inf_fea1 = self.inf_layer1(inf)
        inf_encode_feature = self.inf_encoder(inf_fea1)
        inf_decode_feature = self.inf_decoder(inf_encode_feature)
        inf_structure = self.inf_structure(inf_encode_feature, inf_decode_feature)

        # 可见光图像特征提取分支
        rgb_fea1 = self.rgb_layer1(rgb)
        rgb_encode_feature = self.rgb_encoder(rgb_fea1)
        rgb_decode_feature = self.rgb_decoder(rgb_encode_feature)
        rgb_structure = self.rgb_structure(rgb_encode_feature, rgb_decode_feature)
        # rgb_structure[0]: torch.Size([1, 64, 480, 640])
        # rgb_structure[1]: torch.Size([1, 128, 240, 320])
        # rgb_structure[2]: torch.Size([1, 256, 120, 160])

        # 粗略输出
        rgb_fea2 = self.conv(rgb_decode_feature[0])
        rgb_out1 = rgb_fea2 + rgb

        # rgb_out2 = self.conv(rgb_structure[0])

        # 计算不一致图
        incons_feature = []
        for i in range(len(rgb_structure)):
            # 将雾浓度信息传入交叉注意力模块
            incons_feature.append(self.cross_attention[i](rgb_structure[i], inf_structure[i], fog_level))

        # 根据雾浓度动态调整红外特征权重
        inf_weight = [None for _ in range(3)]
        for i in range(3):
            # 雾越浓，红外权重越高
            dynamic_weight = 1.0 + fog_level * 0.5  # 权重范围: 1.0-1.5
            inf_weight[i] = incons_feature[i] * inf_structure[i] * dynamic_weight

        rgb_fea3 = self.rgb_layer1(rgb_out1)
        rgb_encode_feature_2 = self.rgb_encoder(rgb_fea3, inf_weight)
        rgb_decode_feature_2 = self.rgb_decoder(rgb_encode_feature_2)
        out = self.conv(rgb_decode_feature_2[0])

        return out, rgb_structure, inf_structure, incons_feature, inf_weight
