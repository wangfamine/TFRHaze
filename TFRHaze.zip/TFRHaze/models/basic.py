import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

# Sobel 算子定义
Sobel = np.array([[-1, -2, -1],
                  [0, 0, 0],
                  [1, 2, 1]])
Robert = np.array([[0, 0],
                   [-1, 1]])
Sobel = torch.Tensor(Sobel)
Robert = torch.Tensor(Robert)


class Norm(nn.Module):
    def __init__(self):
        super(Norm, self).__init__()
        self.avg = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        y = self.avg(x)
        x = torch.sign(x - y)
        out = (x + 1) / 2
        return out


def Conv(in_channels, out_channels, kernel_size, stride=1, bias=False):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size // 2), stride=stride, bias=bias)


# class SELayer(nn.Module):
#     def __init__(self, channel, reduction=16, bias=False):
#         super(SELayer, self).__init__()
#         self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         self.conv_du = nn.Sequential(
#                 nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=bias),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=bias),
#                 nn.Sigmoid()
#         )

#     def forward(self, x):
#         y = self.avg_pool(x)
#         y = self.conv_du(y)
#         return x * y

# #   RCAB(ngf, kernel_size, reduction, bias=bias, act=act)

# class RCAB(nn.Module):
#     def __init__(self, n_feat, kernel_size, reduction, bias, act):
#         super(RCAB, self).__init__()
#         feats_cal = []
#         feats_cal.append(Conv(n_feat, n_feat, kernel_size, bias=bias))
#         feats_cal.append(act)
#         feats_cal.append(Conv(n_feat, n_feat, kernel_size, bias=bias))

#         self.SE = SELayer(n_feat, reduction, bias=bias)
#         self.feats_cal = nn.Sequential(*feats_cal)

#     def forward(self, x):
#         feats = self.feats_cal(x)
#         feats = self.SE(feats)
#         feats += x
#         return feats


class PALayer(nn.Module):
    def __init__(self, channel):
        super(PALayer, self).__init__()
        self.pa = nn.Sequential(
            nn.Conv2d(channel, channel // 16, 1, padding=0, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // 16, 1, 1, padding=0, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        y = self.pa(x)
        return x * y


class CALayer(nn.Module):
    def __init__(self, channel):
        super(CALayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.ca = nn.Sequential(
            nn.Conv2d(channel, channel // 16, 1, padding=0, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // 16, channel, 1, padding=0, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.ca(y)
        return x * y


class CPAB(nn.Module):
    def __init__(self, dim, kernel_size, bias):
        super(CPAB, self).__init__()
        self.conv1 = Conv(dim, dim, kernel_size, bias=bias)
        self.act1 = nn.PReLU()
        self.conv2 = Conv(dim, dim, kernel_size, bias=bias)
        self.calayer = CALayer(dim)
        self.palayer = PALayer(dim)

    def forward(self, x):
        res = self.act1(self.conv1(x))
        res = res + x
        res = self.conv2(res)
        res = self.calayer(res)
        res = self.palayer(res)
        res += x
        return res


class Output(nn.Module):
    def __init__(self, n_feat, kernel_size, bias, output_channel=3, residual=True):
        super(Output, self).__init__()
        self.conv = Conv(n_feat, output_channel, kernel_size, bias=bias)
        self.residual = residual

    def forward(self, x, x_img):
        x = self.conv(x)
        if self.residual:
            x += x_img
        return x


class Encoder(nn.Module):
    def __init__(self, n_feat, kernel_size, bias, atten):
        super(Encoder, self).__init__()
        self.atten = atten

        self.encoder_level1 = CPAB(n_feat, kernel_size, bias=bias)
        self.encoder_level2 = CPAB(n_feat * 2, kernel_size, bias=bias)
        self.encoder_level3 = CPAB(n_feat * 4, kernel_size, bias=bias)


        self.down12 = DownSample(n_feat, n_feat * 2)
        self.down23 = DownSample(n_feat * 2, n_feat * 4)

        if self.atten:  # feature attention
            self.atten_conv1 = Conv(n_feat, n_feat, 1, bias=bias)
            self.atten_conv2 = Conv(n_feat * 2, n_feat * 2, 1, bias=bias)
            self.atten_conv3 = Conv(n_feat * 4, n_feat * 4, 1, bias=bias)

    def forward(self, x, encoder_outs=None):
        if encoder_outs is None:
            enc1 = self.encoder_level1(x)
            x = self.down12(enc1)
            enc2 = self.encoder_level2(x)
            x = self.down23(enc2)
            enc3 = self.encoder_level3(x)

            return [enc1, enc2, enc3]
        else:


            enc1 = self.encoder_level1(x)
            enc1_fuse_nir = enc1 + self.atten_conv1(encoder_outs[0])
            x = self.down12(enc1_fuse_nir)
            enc2 = self.encoder_level2(x)
            enc2_fuse_nir = enc2 + self.atten_conv2(encoder_outs[1])
            x = self.down23(enc2_fuse_nir)
            enc3 = self.encoder_level3(x)
            enc3_fuse_nir = enc3 + self.atten_conv3(encoder_outs[2])

            return [enc1_fuse_nir, enc2_fuse_nir, enc3_fuse_nir]


class Decoder(nn.Module):
    def __init__(self, n_feat, kernel_size, bias, residual=True):
        super(Decoder, self).__init__()

        self.residual = residual

        self.decoder_level1 = CPAB(n_feat, kernel_size, bias=bias)
        self.decoder_level2 = CPAB(n_feat * 2, kernel_size, bias=bias)
        self.decoder_level3 = CPAB(n_feat * 4, kernel_size, bias=bias)


        self.skip_conv_1 = Conv(n_feat, n_feat, kernel_size, bias=bias)
        self.skip_conv_2 = Conv(n_feat * 2, n_feat * 2, kernel_size, bias=bias)

        self.up21 = UpSample(n_feat * 2, n_feat)
        self.up32 = UpSample(n_feat * 4, n_feat * 2)

    def forward(self, outs):
        enc1, enc2, enc3 = outs
        dec3 = self.decoder_level3(enc3)

        x = self.up32(dec3)
        if self.residual:
            x += self.skip_conv_2(enc2)
        dec2 = self.decoder_level2(x)

        x = self.up21(dec2)
        if self.residual:
            x += self.skip_conv_1(enc1)
        dec1 = self.decoder_level1(x)

        return [dec1, dec2, dec3]


class DownSample(nn.Module):
    def __init__(self, in_channels, out_channel):
        super(DownSample, self).__init__()
        self.conv = Conv(in_channels, out_channel, 1, stride=1, bias=False)

    def forward(self, x):
        x = F.interpolate(x, scale_factor=0.5, mode='bilinear', align_corners=False)
        x = self.conv(x)
        return x


class UpSample(nn.Module):
    def __init__(self, in_channels, out_channel):
        super(UpSample, self).__init__()
        self.conv = Conv(in_channels, out_channel, 1, stride=1, bias=False)

    def forward(self, x):
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=False)
        x = self.conv(x)
        return x


class Edge(nn.Module):
    def __init__(self, channel, kernel='sobel'):
        super(Edge, self).__init__()
        self.channel = channel
        self.kernel = kernel
        self.kernel_x = Sobel.repeat(channel, 1, 1, 1)
        self.kernel_y = self.kernel_x.permute(0, 1, 3, 2)
        self.kernel_x = nn.Parameter(self.kernel_x, requires_grad=False)
        self.kernel_y = nn.Parameter(self.kernel_y, requires_grad=False)

    def forward(self, current):
        current = F.pad(current, (1, 1, 1, 1), mode='reflect')
        gradient_x = torch.abs(F.conv2d(current, weight=self.kernel_x, groups=self.channel, padding=0))
        gradient_y = torch.abs(F.conv2d(current, weight=self.kernel_y, groups=self.channel, padding=0))
        out = gradient_x + gradient_y
        return out

class LightweightTransformerBlock(nn.Module):
    def __init__(self, dim=64, num_heads=4):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * 4),  # 增加MLP的扩展比例
            nn.GELU(),
            nn.Linear(dim * 4, dim)
        )
        
        # 添加局部特征提取
        self.local_conv = nn.Sequential(
            nn.Conv2d(dim, dim, 3, padding=1),
            nn.GELU(),
            nn.Conv2d(dim, dim, 3, padding=1)
        )

    def forward(self, x):
        # 自注意力
        x_attn, _ = self.attn(x, x, x)
        x = x + x_attn
        
        # 局部特征提取
        B, N, C = x.shape
        H = W = int(N ** 0.5)
        x_local = x.transpose(1, 2).reshape(B, C, H, W)
        x_local = self.local_conv(x_local)
        x_local = x_local.reshape(B, C, N).transpose(1, 2)
        
        # MLP
        x_mlp = self.mlp(self.norm2(x))
        x = x + x_mlp + x_local
        
        return x

class LightweightTransformer(nn.Module):
    def __init__(self, in_channels=3, embed_dim=64, num_heads=4):
        super().__init__()
        self.conv_in = nn.Conv2d(in_channels, embed_dim, 3, padding=1)
        self.transformer = LightweightTransformerBlock(embed_dim, num_heads)
        self.conv_out = nn.Conv2d(embed_dim, embed_dim, 3, padding=1)
        
        # 使用多尺度特征提取
        self.pool1 = nn.AdaptiveAvgPool2d((16, 16))  # 增加分辨率
        self.pool2 = nn.AdaptiveAvgPool2d((8, 8))
        
        # 添加残差连接
        self.skip_conv = nn.Conv2d(embed_dim, embed_dim, 3, padding=1)

    def forward(self, x):
        # 保存原始输入大小
        _, _, orig_h, orig_w = x.shape
        
        # 输入卷积
        x = self.conv_in(x)
        
        # 多尺度特征提取
        x_down1 = self.pool1(x)  # 16x16
        x_down2 = self.pool2(x)  # 8x8
        
        # 处理两个尺度的特征
        B, C, H1, W1 = x_down1.shape
        x_seq1 = x_down1.flatten(2).transpose(1, 2)
        x_seq1 = self.transformer(x_seq1)
        x_down1 = x_seq1.transpose(1, 2).reshape(B, C, H1, W1)
        
        B,  C, H2, W2 = x_down2.shape
        x_seq2 = x_down2.flatten(2).transpose(1, 2)
        x_seq2 = self.transformer(x_seq2)
        x_down2 = x_seq2.transpose(1, 2).reshape(B, C, H2, W2)
        
        # 上采样并融合
        x_down1 = F.interpolate(x_down1, size=(orig_h, orig_w), mode='bilinear', align_corners=False)
        x_down2 = F.interpolate(x_down2, size=(orig_h, orig_w), mode='bilinear', align_corners=False)
        
        # 添加残差连接
        x = x_down1 + x_down2 + self.skip_conv(x)
        
        # 输出卷积
        x = self.conv_out(x)
        return x

#class CrossAttention(nn.Module):
    #def __init__(self, dim, num_heads=4):
        #super().__init__()
        #self.num_heads = num_heads
        #self.scale = (dim // num_heads) ** -0.5

        #self.channel_compress = nn.ModuleList([
            #nn.Conv2d(dim, dim//2, 1),
            #nn.Conv2d(dim, dim//2, 3, padding=1, groups=dim//2)
        #])

        #self.spatial_mixing = nn.Sequential(
            #nn.Conv2d(dim//2, dim//2, 3, padding=1, groups=dim//4),
            #nn.GELU(),
            #nn.Conv2d(dim//2, dim//2, 1)
        #)

        #self.weight_gen = nn.Sequential(
            # 空间注意力
            #nn.Conv2d(dim, dim//4, 7, padding=3, groups=dim//4),
            #nn.GELU(),
            #nn.Conv2d(dim//4, 2, 1),
            #nn.Softmax(dim=1)
       # )

        #self.channel_enhance = nn.Sequential(
            #nn.AdaptiveAvgPool2d(1),
            #nn.Conv2d(dim//2, dim//8, 1),
            #nn.GELU(),
            #nn.Conv2d(dim//8, dim//2, 1),
            #nn.Sigmoid()
       # )

        #self.output_proj = nn.Sequential(
            #nn.Conv2d(dim, dim, 1),
            #nn.GELU()
        #)
        
    #def forward(self, x, y):
        #B, C, H, W = x.shape

        #x_local = self.channel_compress[0](x)
        #x_global = self.channel_compress[1](x)
        #y_local = self.channel_compress[0](y)
        #y_global = self.channel_compress[1](y)

        #x_mixed = self.spatial_mixing(x_local + x_global)
        #y_mixed = self.spatial_mixing(y_local + y_global)

        #weights = self.weight_gen(x)

        #x_enhance = self.channel_enhance(x_mixed) * x_mixed
        #y_enhance = self.channel_enhance(y_mixed) * y_mixed

       # fused = weights[:,0:1] * x_enhance + weights[:,1:2] * y_enhance

        #out = self.output_proj(torch.cat([fused, fused], dim=1))
        
        # 残差连接
        #out = out + x
        
        #return out

class AdaptiveCrossAttention(nn.Module):
    def __init__(self, dim, num_heads=4):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5
        
        # 1. 特征压缩
        self.channel_compress = nn.Conv2d(dim, dim//2, 1)
        self.channel_expand = nn.Conv2d(dim//2, dim, 1)
        
        # 2. 适应雾浓度的特征交互
        self.spatial_mixing = nn.Sequential(
            nn.Conv2d(dim//2, dim//2, 3, padding=1, groups=dim//2),
            nn.GELU(),
            nn.Conv2d(dim//2, dim//2, 1)
        )
        
        # 3. 增强型权重生成
        self.weight_gen = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim + 1, dim//8, 1),  # +1用于接收雾浓度信息
            nn.GELU(),
            nn.Conv2d(dim//8, 2, 1),
            nn.Softmax(dim=1)
        )
        
        # 4. 红外增强通道
        self.ir_enhance = nn.Sequential(
            nn.Conv2d(dim//2, dim//2, 3, padding=1),
            nn.GELU(),
            nn.Conv2d(dim//2, dim//2, 3, padding=1)
        )
        
    def forward(self, x, y, fog_level=None):
        B, C, H, W = x.shape
        
        # 默认雾浓度为中等如果未提供
        if fog_level is None:
            fog_level = torch.ones((B, 1, 1, 1), device=x.device) * 0.5
        
        # 扩展雾浓度到与x相同的空间维度
        fog_info = fog_level.expand(B, 1, 1, 1)
        
        # 特征压缩
        x_comp = self.channel_compress(x)
        y_comp = self.channel_compress(y)
        
        # 基本特征处理
        x_mixed = self.spatial_mixing(x_comp)
        
        # 根据雾浓度增强红外特征
        y_enhanced = self.ir_enhance(y_comp)
        y_mixed = y_comp + y_enhanced * fog_level  # 雾越浓，增强越明显
        
        # 生成自适应权重，考虑雾浓度
        # 将雾信息拼接到特征上
        x_with_fog = torch.cat([x, fog_info.expand(B, 1, H, W)], dim=1)
        weights = self.weight_gen(x_with_fog)
        
        # 根据雾浓度调整基础权重
        fog_factor = 0.3 * fog_level.squeeze(-1).squeeze(-1)  # 雾浓度影响因子
        # 雾越浓，红外权重越高
        adjusted_weights = torch.cat([
            weights[:, 0:1] * (1 - fog_factor),  # 降低RGB权重
            weights[:, 1:2] * (1 + fog_factor)   # 提高红外权重
        ], dim=1)
        
        adjusted_weights = F.softmax(adjusted_weights, dim=1)  # 重新归一化
        
        # 自适应融合
        fused = adjusted_weights[:, 0:1] * x_mixed + adjusted_weights[:, 1:2] * y_mixed
        
        # 特征扩展
        out = self.channel_expand(fused)
        
        # 残差连接
        out = out + x
        
        return out