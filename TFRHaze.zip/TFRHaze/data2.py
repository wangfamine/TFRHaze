import os
import glob
from PIL import Image

# 输入和输出路径
input_dir = r"D:\TFRHaze\wutu\data"
output_dir = r"D:\TFRHaze\wutu\out"


os.makedirs(output_dir, exist_ok=True)


image_files = glob.glob(os.path.join(input_dir, "*.png"))

# 重新命名并保存图片
for idx, image_file in enumerate(image_files, start=1):
    img = Image.open(image_file)
    new_name = f"{idx}_rgb_foggy_1.0.png"
    img.save(os.path.join(output_dir, new_name))

print("Foggy images saved successfully.")