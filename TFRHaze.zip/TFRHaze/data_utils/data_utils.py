import torch.utils.data as data
import torchvision.transforms as tfs
from torchvision.transforms import functional as FF
import os
import random
from PIL import Image
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from torchvision.utils import make_grid
from metrics import *
from option import opt


BS = opt.bs
print('batch size is:', BS)
crop_size = 'whole_img'
if opt.crop:
    crop_size = opt.crop_size    # (240,240)
else:
    crop_size = 'whole_img'


def tensorShow(tensors, titles=None):
        fig = plt.figure()
        for tensor, tit, i in zip(tensors, titles, range(len(tensors))):
            img = make_grid(tensor)
            npimg = img.numpy()
            ax = fig.add_subplot(211+i)
            ax.imshow(np.transpose(npimg, (1, 2, 0)))
            ax.set_title(tit)
        plt.show()


class RGB_Dataset(data.Dataset):
    def __init__(self, path, train, size=None, input_h=480, input_w=640, format='.png'):
        super(RGB_Dataset, self).__init__()
        self.size = size
        self.train = train
        self.format = format
        self.input_h = input_h
        self.input_w = input_w

        # ---------- 关键修正点 ----------
        # 假设 path 指向 foggy_0.5/train 目录
        # 例如：path = "data/ym/multidata/Airsim-VID/foggy_0.5/train"

        # 1. 定义各子目录路径
        self.haze_dir = os.path.join(path, 'haze')  # 有雾图像目录
        self.clear_dir = os.path.join(path, 'clear')  # 清晰图像目录
        self.nir_dir = os.path.join(path, 'nir')  # 近红外图像目录

        # 2. 验证目录是否存在
        self._check_dir_exists(self.haze_dir, "haze")
        self._check_dir_exists(self.clear_dir, "clear")
        self._check_dir_exists(self.nir_dir, "nir")

        # 3. 获取有雾图像文件列表（仅包含指定格式的文件）
        self.haze_imgs = [
            os.path.join(self.haze_dir, f)
            for f in os.listdir(self.haze_dir)
            if f.endswith(self.format)
        ]
        # ---------------------------------

        print(f"成功加载 {len(self.haze_imgs)} 个有雾图像样本")

    def _check_dir_exists(self, dir_path, dir_name):
        """检查目录是否存在，若不存在则抛出明确错误"""
        if not os.path.exists(dir_path):
            raise FileNotFoundError(
                f"目录 '{dir_name}' 不存在于路径中: {os.path.abspath(dir_path)}\n"
                f"请确认数据集结构是否为：{os.path.dirname(dir_path)}/{{haze, clear, nir}}"
            )

    def __getitem__(self, index):
        haze_img_path = self.haze_imgs[index]
        file_name = os.path.basename(haze_img_path)  # 示例: "248_rgb_foggy_0.5.png"

        # 正确提取 ID（假设文件名格式为 {id}_rgb_foggy_{version}.png）
        id = file_name.split('_')[0]  # 提取 "248"

        # 生成清晰图像文件名（假设清晰图像文件名为 {id}_rgb.png）
        clear_name = f"{id}_rgb.png"
        clear_path = os.path.join(self.clear_dir, clear_name)

        # 检查清晰图像路径是否存在
        if not os.path.exists(clear_path):
            raise FileNotFoundError(f"清晰图像文件不存在: {os.path.abspath(clear_path)}")

        # 生成近红外图像文件名（假设文件名为 {id}_thermal_foggy_0.5.png）
        nir_name = f"{id}_thermal_foggy_1.5.png"
        nir_path = os.path.join(self.nir_dir, nir_name)

        # 检查近红外图像路径是否存在
        if not os.path.exists(nir_path):
            raise FileNotFoundError(f"近红外图像文件不存在: {os.path.abspath(nir_path)}")

        # 读取并处理图像（添加异常处理）
        try:
            haze = Image.open(haze_img_path).convert("RGB")
            clear = Image.open(clear_path).convert("RGB")
            nir = Image.open(nir_path).convert("RGB")
        except Exception as e:
            raise RuntimeError(f"读取图像失败: {e}")

        # 转换为 Tensor 并返回
        haze = self._process_image(haze)
        clear = self._process_image(clear)
        nir = self._process_image(nir)

        return haze, nir, clear

    def _process_image(self, img):
        """统一处理图像缩放和归一化"""
        img = img.resize((self.input_w, self.input_h))
        img = np.asarray(img, dtype=np.float32).transpose((2, 0, 1)) / 255
        return torch.tensor(img)

    def __len__(self):
        return len(self.haze_imgs)


class val_Dataset(data.Dataset):
    def __init__(self, path, train, size=crop_size, input_h=480, input_w=640, format='.png'):
        super(val_Dataset, self).__init__()
        self.size = size
        print('crop size', size)
        self.train = train
        self.format = format
        self.input_h = input_h
        self.input_w = input_w
        self.haze_imgs_dir = os.listdir(os.path.join(path, 'haze'))   # haze
        self.haze_imgs = [os.path.join(path, 'haze', img) for img in self.haze_imgs_dir]   # haze
        self.nir_dir = os.path.join(path, 'nir')

    def __getitem__(self, index):
        haze_img_path = self.haze_imgs[index]
        file_name = os.path.basename(haze_img_path)  # 示例: "248_rgb_foggy_0.5.png"
        id = file_name.split('_')[0]  # 提取 "248"

        # 生成近红外图像文件名（假设文件名为 {id}_thermal.png）
        nir_name = f"{id}_thermal.png"
        nir_path = os.path.join(self.nir_dir, nir_name)

        # 检查路径是否存在
        if not os.path.exists(nir_path):
            raise FileNotFoundError(f"近红外图像文件不存在: {os.path.abspath(nir_path)}")

        # 读取并处理图像
        haze = Image.open(haze_img_path).convert("RGB")
        nir = Image.open(nir_path).convert("RGB")

        haze = self._process_image(haze)
        nir = self._process_image(nir)

        return haze, nir

    def __len__(self):
        return len(self.haze_imgs)


path = 'data/ym/multidata/Airsim-VID/foggy_1.5'  # 根目录

# 训练集路径应为 path + '/train'
RGB_train_loader = DataLoader(dataset=RGB_Dataset(path+'/train',
                               train=True, format='.png'), batch_size=BS, shuffle=True)
RGB_test_loader = DataLoader(dataset=RGB_Dataset(path+'/test',
                               train=False, size='whole img', format='.png'), batch_size=1, shuffle=False)
RGB_val_loader = DataLoader(dataset=RGB_Dataset(path+'/val',
                               train=False, size='whole img', format='.png'), batch_size=1, shuffle=False)

if __name__ == "__main__":
    pass
