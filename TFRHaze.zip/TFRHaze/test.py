import os
import argparse
import numpy as np
import re
import csv
from PIL import Image
import torch
import torch.nn as nn
import torchvision.transforms as tfs
import torchvision.utils as vutils
import matplotlib.pyplot as plt
from torchvision.utils import make_grid
from data_utils.data_utils import *
from models.TFRHaze import *
import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
from models.mssim import MSSSIM

# 添加数字排序函数
def extract_number(filename):
    """从文件名中提取数字"""
    numbers = re.findall(r'\d+', filename)
    return int(numbers[0]) if numbers else 0

def create_numeric_ordered_dataset(path, format='.png', input_h=480, input_w=640):
    """创建按数字顺序排序的数据集"""
    haze_dir = os.path.join(path, 'haze')
    clear_dir = os.path.join(path, 'clear')
    nir_dir = os.path.join(path, 'nir')
    
    # 检查目录是否存在
    for dir_path, dir_name in [(haze_dir, "haze"), (clear_dir, "clear"), (nir_dir, "nir")]:
        if not os.path.exists(dir_path):
            raise FileNotFoundError(f"目录 '{dir_name}' 不存在于路径中: {os.path.abspath(dir_path)}")
    
    # 获取有雾图像文件列表并按数字排序
    haze_files = [f for f in os.listdir(haze_dir) if f.endswith(format)]
    haze_files.sort(key=extract_number)
    
    haze_paths = [os.path.join(haze_dir, f) for f in haze_files]
    
    # 预处理数据
    data_list = []
    for haze_path in haze_paths:
        file_name = os.path.basename(haze_path)
        id = file_name.split('_')[0]
        
        # 生成清晰图像和红外图像的路径
        clear_path = os.path.join(clear_dir, f"{id}_rgb.png")
        nir_path = os.path.join(nir_dir, f"{id}_thermal_foggy_1.5.png")
        
        # 检查文件是否存在
        if not os.path.exists(clear_path):
            print(f"警告: 清晰图像不存在: {clear_path}")
            continue
        if not os.path.exists(nir_path):
            print(f"警告: 红外图像不存在: {nir_path}")
            continue
        
        # 读取并处理图像
        try:
            haze = Image.open(haze_path).convert("RGB")
            clear = Image.open(clear_path).convert("RGB")
            nir = Image.open(nir_path).convert("RGB")
            

            haze = haze.resize((input_w, input_h))
            clear = clear.resize((input_w, input_h))
            nir = nir.resize((input_w, input_h))
            

            haze_tensor = torch.tensor(np.asarray(haze, dtype=np.float32).transpose((2, 0, 1)) / 255)
            clear_tensor = torch.tensor(np.asarray(clear, dtype=np.float32).transpose((2, 0, 1)) / 255)
            nir_tensor = torch.tensor(np.asarray(nir, dtype=np.float32).transpose((2, 0, 1)) / 255)
            
            data_list.append((haze_tensor, nir_tensor, clear_tensor, file_name))
        except Exception as e:
            print(f"处理图像时出错: {e}")
            continue
    
    print(f"成功加载 {len(data_list)} 个图像，按数字顺序排序")
    return data_list

# 主函数
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test_path', type=str, default='data/ym/multidata/Airsim-VID/foggy_1.5/test', help='Test data path')
    parser.add_argument('--model_path', type=str, default='trained_models/tfrhaze.pk.best.best', help='Model path')
    parser.add_argument('--output_dir', type=str, default='pred_imgs_rgbt/', help='Output directory')
    parser.add_argument('--batch_size', type=int, default=1, help='Batch size')
    parser.add_argument('--metrics_file', type=str, default='metrics_results.csv', help='CSV file to save metrics')
    opt = parser.parse_args()
    
    # 创建输出目录
    if not os.path.exists(opt.output_dir):
        os.makedirs(opt.output_dir)
    
    # 加载按数字顺序排序的数据集
    dataset = create_numeric_ordered_dataset(opt.test_path)
    
    # 加载模型
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    ckp = torch.load(opt.model_path, map_location=device)
    net = tfrhaze(3, 3)
    net = nn.DataParallel(net)
    net.load_state_dict(ckp['model'])
    net.eval()
    net = net.to(device)
    

    total_ssim = 0.0
    total_psnr = 0.0
    
    # 准备CSV文件保存结果
    metrics_path = os.path.join(opt.output_dir, opt.metrics_file)
    with open(metrics_path, 'w', newline='') as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(['Image', 'SSIM', 'PSNR'])
        
        with torch.no_grad():
            all_results = []
            
            for i, (haze, nir, clear, filename) in enumerate(dataset):
                haze = haze.unsqueeze(0).to(device)
                nir = nir.unsqueeze(0).to(device)
                clear = clear.unsqueeze(0).to(device)
                
                # 前向传播
                out, _, _, _, _ = net(haze, nir)
                
                # 计算指标
                current_ssim = ssim(out, clear).item()
                current_psnr = psnr(out, clear)
                total_ssim += current_ssim
                total_psnr += current_psnr
                
                # 保存结果
                output_img = torch.squeeze(out.clamp(0, 1).cpu())
                output_path = os.path.join(opt.output_dir, f"dehazed_{filename}")
                vutils.save_image(output_img, output_path)
                
                # 保存到CSV
                csv_writer.writerow([filename, f"{current_ssim:.4f}", f"{current_psnr:.4f}"])
                
                # 将结果添加到列表中
                all_results.append({
                    'filename': filename,
                    'image_id': extract_number(filename),
                    'ssim': current_ssim,
                    'psnr': current_psnr
                })

                print(f"处理: {filename} | SSIM: {current_ssim:.4f} | PSNR: {current_psnr:.4f}")

            sorted_results = sorted(all_results, key=lambda x: x['image_id'])
            sorted_metrics_path = os.path.join(opt.output_dir, 'sorted_' + opt.metrics_file)
            with open(sorted_metrics_path, 'w', newline='') as sorted_file:
                sorted_writer = csv.writer(sorted_file)
                sorted_writer.writerow(['Image_ID', 'Image', 'SSIM', 'PSNR'])
                for result in sorted_results:
                    sorted_writer.writerow([
                        result['image_id'],
                        result['filename'],
                        f"{result['ssim']:.4f}",
                        f"{result['psnr']:.4f}"
                    ])
    
    # 计算平均指标
    avg_ssim = total_ssim / len(dataset)
    avg_psnr = total_psnr / len(dataset)
    
    # 添加平均结果到CSV文件
    with open(metrics_path, 'a', newline='') as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(['平均值', f"{avg_ssim:.4f}", f"{avg_psnr:.4f}"])
    
    print(f"\n处理完成! 总共处理了 {len(dataset)} 张图像")
    print(f"平均 SSIM: {avg_ssim:.4f}")
    print(f"平均 PSNR: {avg_psnr:.4f}")
    print(f"结果已保存到CSV文件: {metrics_path}")
    print(f"按ID排序的结果已保存到: {sorted_metrics_path}")

if __name__ == "__main__":
    main() 